1) We reference the other files in this directory so ensure all files in the directory are included.
2) We use nltk for tweet processing. To install nltk run: sudo apt-get install python-nltk . If you do not have a machine that uses apt-get 
please see here: http://www.nltk.org/install.html.
3) To run our assignment: just run "python main.py".  This will also produce  clintontrump.predictions.dev please note this was only done for the Bernoulli model (since it was not specified). This file is written in BernoulliTest and is finally formed the last time BernoulliTest is called. Please also note 1=HillaryClinton 0=DonaldTrump.

Thanks!

